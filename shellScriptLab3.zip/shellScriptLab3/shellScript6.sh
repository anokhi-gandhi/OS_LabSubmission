for i in $#
do
	$*
done


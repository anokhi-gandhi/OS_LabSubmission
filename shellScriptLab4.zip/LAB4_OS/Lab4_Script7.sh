echo INPUT FILENAME
read fName
echo Type y to revoke the read and write permissions for file "$fName"
read ans
if [ $ans = 'y' -o $ans = 'Y' ]
then 
echo Write permission code
read code
chmod $code $fName
else
echo File permissions not changed
fi

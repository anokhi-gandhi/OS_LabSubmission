echo "Input filename"
read fName
cat $fName | wc -w


echo "Enter a number to get sum upto that number"
read no
n=`expr $no + 1 `
k=`expr $no \* $n `
ans=`expr $k / 2 `
echo $ans
 


echo "Input basic salary";
read salary;
if [ "$salary" -gt "0" ] 
then
echo "0.12 * $salary" | bc
else
echo "Input valid salary"
fi


#hra= $((b*HRA));


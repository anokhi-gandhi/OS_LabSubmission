echo "Input filenmane"
read fName
cat $fName | tr -d '\n' | tr -s " " '\n' | wc -l

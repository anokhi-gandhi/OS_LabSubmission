dt=`date|cut -d " " -f 5|cut -d ":" -f 1`
echo $dt
if [ $dt -gt 4 -a $dt -lt 12 ]
then
echo Good Morning
elif [ $dt -gt 12 -a $dt -lt 16 ]
then
echo Good Afternoon
elif [ $dt -gt 16 -a $dt -lt 20 ]
then
echo Good Evening
else
echo Good Night
fi


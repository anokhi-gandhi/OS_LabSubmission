echo "Input pattern ";
read P;
echo "Input file name to match string pattern ";
read fName;
grep $P $fName;
if [ $? -eq 0 ]
then              
echo Pattern found ;
else
echo Pattern not found;
fi

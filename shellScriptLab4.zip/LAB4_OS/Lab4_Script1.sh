#!/bin/bash

opt=1;
while [ $opt -ne 0 ] 
do
echo Input a number less than 50 to calculate its square
read S
if [ $S -gt 50 ] 
then
echo "enter a number < 50"
else
ans=$(($S*$S))
echo the square of input no is "$ans"
fi
echo "Press 0 to exit, any number to continue....!!!"
read opt
done

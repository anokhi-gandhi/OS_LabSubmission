echo 'Input filename to calculate new line charachters'
read fName
cat $fName | wc -l
